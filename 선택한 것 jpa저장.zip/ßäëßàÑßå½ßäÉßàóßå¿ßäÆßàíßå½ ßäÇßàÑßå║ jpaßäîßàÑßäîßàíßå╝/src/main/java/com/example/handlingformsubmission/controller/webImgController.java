package com.example.handlingformsubmission.controller;
import com.example.handlingformsubmission.model.imgData.imgData;
import com.example.handlingformsubmission.model.imgData.ImgDataRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class webImgController {

	@Autowired
	private ImgDataRepository imgDataRepository;

	WebImg webImg = new WebImg();
	private static final Logger LOG = LoggerFactory.getLogger(webImgController.class);

	@GetMapping("/webImg")
	public String imgForm(Model model) {
		model.addAttribute("webImg", new WebImg());
		return "webImg";

	}

	@PostMapping("/webImg")
	public String imgSubmit(@ModelAttribute WebImg webImg, Model model) {
		model.addAttribute("webImg", webImg);
		LOG.info("요약뷰 정보 출력");
		LOG.info(webImg.getContent());
		imgData data = new imgData(webImg.getContent());
		imgDataRepository.save(data);
		System.out.println("저장된 데이터 확인");
		System.out.println(data.getMsg());
		return "webImg";
	}

}
