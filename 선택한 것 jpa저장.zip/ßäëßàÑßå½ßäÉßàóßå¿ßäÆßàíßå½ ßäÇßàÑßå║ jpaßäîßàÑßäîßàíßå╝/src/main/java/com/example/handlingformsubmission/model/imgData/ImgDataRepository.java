package com.example.handlingformsubmission.model.imgData;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ImgDataRepository extends CrudRepository<imgData, Long> {

	List<imgData> findByMsg(String msg);

	imgData findById(long id);
}
