package com.example.handlingformsubmission.controller;

public class WebImg {

    private String content;
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

}
